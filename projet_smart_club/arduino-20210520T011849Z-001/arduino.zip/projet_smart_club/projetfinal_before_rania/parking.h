#ifndef PARKING_H
#define PARKING_H


class parking
{
public:
    parking();
};

#endif // PARKING_H
