<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ar" sourcelanguage="en">
<context>
    <name>Dialogmain</name>
    <message>
        <location filename="dialogmain.ui" line="14"/>
        <source>Dialog</source>
        <translation></translation>
    </message>
    <message>
        <location filename="dialogmain.ui" line="52"/>
        <source>Next Table</source>
        <translation>الجدول التالي</translation>
    </message>
    <message>
        <location filename="dialogmain.ui" line="65"/>
        <source>SEANCES</source>
        <translation>الحصص</translation>
    </message>
    <message>
        <location filename="dialogmain.ui" line="82"/>
        <location filename="dialogmain.ui" line="711"/>
        <source>CREATE</source>
        <translation>أضف</translation>
    </message>
    <message>
        <location filename="dialogmain.ui" line="94"/>
        <location filename="dialogmain.ui" line="785"/>
        <source>ADD</source>
        <translation>أضف</translation>
    </message>
    <message>
        <location filename="dialogmain.ui" line="110"/>
        <source>ID SEANCE :</source>
        <translation>هوية الحصة</translation>
    </message>
    <message>
        <location filename="dialogmain.ui" line="117"/>
        <source>DATE SCEANCE : </source>
        <translation>موعد الحصة</translation>
    </message>
    <message>
        <location filename="dialogmain.ui" line="124"/>
        <source>HEURE DEBUT :</source>
        <translation>ساعة بدء الحصة</translation>
    </message>
    <message>
        <location filename="dialogmain.ui" line="131"/>
        <source>HEURE FIN : </source>
        <translation>ساعة إنتهاء الحصة</translation>
    </message>
    <message>
        <location filename="dialogmain.ui" line="138"/>
        <source>LIEU :</source>
        <translation>المكان</translation>
    </message>
    <message>
        <location filename="dialogmain.ui" line="145"/>
        <source>PRIX : </source>
        <translation>الثمن</translation>
    </message>
    <message>
        <location filename="dialogmain.ui" line="168"/>
        <location filename="dialogmain.ui" line="252"/>
        <source>SOUSSE</source>
        <translation>سوسة</translation>
    </message>
    <message>
        <location filename="dialogmain.ui" line="173"/>
        <location filename="dialogmain.ui" line="257"/>
        <source>ARIANA</source>
        <translation>اريانة</translation>
    </message>
    <message>
        <location filename="dialogmain.ui" line="178"/>
        <location filename="dialogmain.ui" line="262"/>
        <source>TUNIS</source>
        <translation>تونس</translation>
    </message>
    <message>
        <location filename="dialogmain.ui" line="188"/>
        <location filename="dialogmain.ui" line="791"/>
        <source>MANAGE</source>
        <translation>التصرف</translation>
    </message>
    <message>
        <location filename="dialogmain.ui" line="210"/>
        <location filename="dialogmain.ui" line="813"/>
        <source>EDIT</source>
        <translation>تعديل
</translation>
    </message>
    <message>
        <location filename="dialogmain.ui" line="223"/>
        <location filename="dialogmain.ui" line="826"/>
        <source>DELETE</source>
        <translation>حذف
</translation>
    </message>
    <message>
        <location filename="dialogmain.ui" line="300"/>
        <location filename="dialogmain.ui" line="1104"/>
        <source>        v</source>
        <translation></translation>
    </message>
    <message>
        <location filename="dialogmain.ui" line="331"/>
        <location filename="dialogmain.ui" line="1135"/>
        <source>    ^</source>
        <translation></translation>
    </message>
    <message>
        <location filename="dialogmain.ui" line="362"/>
        <location filename="dialogmain.ui" line="424"/>
        <location filename="dialogmain.ui" line="486"/>
        <location filename="dialogmain.ui" line="548"/>
        <location filename="dialogmain.ui" line="610"/>
        <location filename="dialogmain.ui" line="887"/>
        <location filename="dialogmain.ui" line="918"/>
        <location filename="dialogmain.ui" line="949"/>
        <location filename="dialogmain.ui" line="1042"/>
        <source>^</source>
        <translation></translation>
    </message>
    <message>
        <location filename="dialogmain.ui" line="393"/>
        <location filename="dialogmain.ui" line="455"/>
        <location filename="dialogmain.ui" line="517"/>
        <location filename="dialogmain.ui" line="579"/>
        <location filename="dialogmain.ui" line="641"/>
        <location filename="dialogmain.ui" line="980"/>
        <location filename="dialogmain.ui" line="1011"/>
        <location filename="dialogmain.ui" line="1073"/>
        <location filename="dialogmain.ui" line="1166"/>
        <source>v</source>
        <translation></translation>
    </message>
    <message>
        <location filename="dialogmain.ui" line="664"/>
        <source>STATS</source>
        <translation>الإحصاء
</translation>
    </message>
    <message>
        <location filename="dialogmain.ui" line="681"/>
        <source>Previous Table</source>
        <translation>الجدول السابق</translation>
    </message>
    <message>
        <location filename="dialogmain.ui" line="694"/>
        <source>COURS</source>
        <translation>الدورات</translation>
    </message>
    <message>
        <location filename="dialogmain.ui" line="726"/>
        <source>COUR ID :</source>
        <translation>هوية الدورة</translation>
    </message>
    <message>
        <location filename="dialogmain.ui" line="739"/>
        <source>NBR OBJECTIVES: </source>
        <translation>عدد الأهداف</translation>
    </message>
    <message>
        <location filename="dialogmain.ui" line="749"/>
        <source>NBR PARTICIPANT:</source>
        <translation>عدد المشاركين</translation>
    </message>
    <message>
        <location filename="dialogmain.ui" line="759"/>
        <source>NBR SEANCES REQ :</source>
        <translation>عدد الحصص المطلوبة</translation>
    </message>
    <message>
        <location filename="dialogmain.ui" line="769"/>
        <source>TITRE : </source>
        <translation>العنوان</translation>
    </message>
    <message>
        <location filename="dialogmain.ui" line="1193"/>
        <source>Next Module</source>
        <translation>الوحدة التالية
</translation>
    </message>
    <message>
        <location filename="dialogmain.ui" line="1206"/>
        <source>AMRI SIDKI MODULE</source>
        <translation></translation>
    </message>
    <message>
        <location filename="dialogmain.ui" line="1219"/>
        <source>dark mode</source>
        <translation>الوضع الداكن</translation>
    </message>
    <message>
        <location filename="dialogmain.ui" line="1234"/>
        <source>Previous Module</source>
        <translation>الوحدة السابقة
</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="cours.cpp" line="42"/>
        <location filename="cours.cpp" line="96"/>
        <source>ID COUR</source>
        <translation>هوية الدورة</translation>
    </message>
    <message>
        <location filename="cours.cpp" line="43"/>
        <location filename="cours.cpp" line="97"/>
        <source>TITRE</source>
        <translation>العنوان</translation>
    </message>
    <message>
        <location filename="cours.cpp" line="44"/>
        <location filename="cours.cpp" line="98"/>
        <source>NBR OBJECTIF</source>
        <translation>عدد الأهداف</translation>
    </message>
    <message>
        <location filename="cours.cpp" line="45"/>
        <location filename="cours.cpp" line="99"/>
        <source>NBR PARTICIPANTS</source>
        <translation>عدد المشاركين</translation>
    </message>
    <message>
        <location filename="cours.cpp" line="46"/>
        <location filename="cours.cpp" line="100"/>
        <source>NBR SEANCES REQUISES</source>
        <translation>عدد الحصص المطلوبة</translation>
    </message>
    <message>
        <location filename="dialogmain.cpp" line="100"/>
        <location filename="dialogmain.cpp" line="112"/>
        <location filename="dialogmain.cpp" line="122"/>
        <location filename="dialogmain.cpp" line="225"/>
        <location filename="dialogmain.cpp" line="237"/>
        <location filename="dialogmain.cpp" line="248"/>
        <source>ADD</source>
        <translation>أضف</translation>
    </message>
    <message>
        <location filename="dialogmain.cpp" line="101"/>
        <location filename="dialogmain.cpp" line="226"/>
        <source>
 ADDED SUCCESSFULY !
</source>
        <translation>تمت إضافة النجاح</translation>
    </message>
    <message>
        <location filename="dialogmain.cpp" line="113"/>
        <source>
 ERROR ID IS PK  !
</source>
        <translation>خطأ الهوية يجب أن تكون مميزة</translation>
    </message>
    <message>
        <location filename="dialogmain.cpp" line="123"/>
        <location filename="dialogmain.cpp" line="249"/>
        <source>
 ID CAN NOT BE NULL !
</source>
        <translation>الهوية لا يمكن أن تكون فارغة</translation>
    </message>
    <message>
        <location filename="dialogmain.cpp" line="173"/>
        <location filename="dialogmain.cpp" line="186"/>
        <location filename="dialogmain.cpp" line="295"/>
        <location filename="dialogmain.cpp" line="308"/>
        <source>MODIFY</source>
        <translation>تعديل</translation>
    </message>
    <message>
        <location filename="dialogmain.cpp" line="174"/>
        <location filename="dialogmain.cpp" line="296"/>
        <source>MODIFIED SUCCESSFULY ! ! .
Click Ok to exit.</source>
        <translation>تم التعديل بنجاح</translation>
    </message>
    <message>
        <location filename="dialogmain.cpp" line="187"/>
        <location filename="dialogmain.cpp" line="309"/>
        <source>ERROR FILL ALL THE INFO.
Click Cancel to exit.</source>
        <translation>خطأ ، الرجاء ملء جميع المعلومات</translation>
    </message>
    <message>
        <location filename="dialogmain.cpp" line="238"/>
        <source>
 ERROR ID IS A PK !
</source>
        <translation>خطأ الهوية يجب أن تكون مميزة</translation>
    </message>
    <message>
        <location filename="dialogmain.cpp" line="431"/>
        <source>SEANCE</source>
        <translation>الحصص</translation>
    </message>
    <message>
        <location filename="dialogmain.cpp" line="432"/>
        <location filename="dialogmain.cpp" line="453"/>
        <source>NO MATCH FOUND !.
Click Cancel to exit.</source>
        <translation>لا يوجد</translation>
    </message>
    <message>
        <location filename="dialogmain.cpp" line="452"/>
        <source>COURS</source>
        <translation>الدورات</translation>
    </message>
    <message>
        <location filename="main.cpp" line="18"/>
        <location filename="main.cpp" line="22"/>
        <source>CONNEXION</source>
        <translation>جاري الربط</translation>
    </message>
    <message>
        <location filename="main.cpp" line="19"/>
        <source>
 DATABASE IS OPEN  !
</source>
        <translation>قاعدة البيانات مفتوحة</translation>
    </message>
    <message>
        <location filename="main.cpp" line="23"/>
        <source>
 DATABASE IS NOT OPEN  !
</source>
        <translation>قاعدة البيانات مغلقة</translation>
    </message>
    <message>
        <location filename="seances.cpp" line="45"/>
        <location filename="seances.cpp" line="104"/>
        <source>ID SEANCE</source>
        <translation>هوية الحصة</translation>
    </message>
    <message>
        <location filename="seances.cpp" line="46"/>
        <location filename="seances.cpp" line="105"/>
        <source>DATE</source>
        <translation>التوقيت</translation>
    </message>
    <message>
        <location filename="seances.cpp" line="47"/>
        <location filename="seances.cpp" line="106"/>
        <source>HEURE DEBUT</source>
        <translation>ساعة البدء</translation>
    </message>
    <message>
        <location filename="seances.cpp" line="48"/>
        <location filename="seances.cpp" line="107"/>
        <source>HEURE FIN</source>
        <translation>ساعة الإنتهاء</translation>
    </message>
    <message>
        <location filename="seances.cpp" line="49"/>
        <location filename="seances.cpp" line="108"/>
        <source>LIEU</source>
        <translation>المكان</translation>
    </message>
    <message>
        <location filename="seances.cpp" line="50"/>
        <location filename="seances.cpp" line="109"/>
        <source>PRIX</source>
        <translation>الثمن</translation>
    </message>
</context>
<context>
    <name>statcours</name>
    <message>
        <location filename="statcours.ui" line="14"/>
        <source>Dialog</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>statistiques</name>
    <message>
        <location filename="statistiques.ui" line="14"/>
        <source>Dialog</source>
        <translation></translation>
    </message>
</context>
</TS>
